-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: db:3306
-- Generation Time: Mar 12, 2022 at 08:32 AM
-- Server version: 5.7.34
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `odbtranslation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `name` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Triggers `admin_user`
--
DELIMITER $$
CREATE TRIGGER `credit_refs` AFTER UPDATE ON `admin_user` FOR EACH ROW BEGIN
    
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `allowed_peer_ip`
--

CREATE TABLE `allowed_peer_ip` (
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip_range` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `denied_peer_ip`
--

CREATE TABLE `denied_peer_ip` (
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip_range` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_key`
--

CREATE TABLE `oauth_key` (
  `kid` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `ikm_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `as_rs_alg` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_abbr`
--

CREATE TABLE `ot_abbr` (
  `abbrID` tinyint(3) UNSIGNED NOT NULL,
  `code` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `chaptersNum` tinyint(3) UNSIGNED NOT NULL,
  `difficulty` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `category` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'bible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ot_abbr`
--

INSERT INTO `ot_abbr` (`abbrID`, `code`, `name`, `chaptersNum`, `difficulty`, `category`) VALUES
(1, 'gen', 'Genesis', 50, '2', 'bible'),
(2, 'exo', 'Exodus', 40, '2', 'bible'),
(3, 'lev', 'Leviticus', 27, '3', 'bible'),
(4, 'num', 'Numbers', 36, '2', 'bible'),
(5, 'deu', 'Deuteronomy', 34, '2', 'bible'),
(6, 'jos', 'Joshua', 24, '1', 'bible'),
(7, 'jdg', 'Judges', 21, '1', 'bible'),
(8, 'rut', 'Ruth', 4, '1', 'bible'),
(9, '1sa', '1 Samuel', 31, '1', 'bible'),
(10, '2sa', '2 Samuel', 24, '1', 'bible'),
(11, '1ki', '1 Kings', 22, '1', 'bible'),
(12, '2ki', '2 Kings', 25, '1', 'bible'),
(13, '1ch', '1 Chronicles', 29, '1', 'bible'),
(14, '2ch', '2 Chronicles', 36, '1', 'bible'),
(15, 'ezr', 'Ezra', 10, '1', 'bible'),
(16, 'neh', 'Nehemiah', 13, '1', 'bible'),
(17, 'est', 'Esther', 10, '1', 'bible'),
(18, 'job', 'Job', 42, '4', 'bible'),
(19, 'psa', 'Psalms', 150, '4', 'bible'),
(20, 'pro', 'Proverbs', 31, '3', 'bible'),
(21, 'ecc', 'Ecclesiastes', 12, '3', 'bible'),
(22, 'sng', 'Song of Solomon', 8, '3', 'bible'),
(23, 'isa', 'Isaiah', 66, '4', 'bible'),
(24, 'jer', 'Jeremiah', 52, '4', 'bible'),
(25, 'lam', 'Lamentations', 5, '3', 'bible'),
(26, 'ezk', 'Ezekiel', 48, '4', 'bible'),
(27, 'dan', 'Daniel', 12, '3', 'bible'),
(28, 'hos', 'Hosea', 14, '3', 'bible'),
(29, 'jol', 'Joel', 3, '3', 'bible'),
(30, 'amo', 'Amos', 9, '3', 'bible'),
(31, 'oba', 'Obadiah', 1, '3', 'bible'),
(32, 'jon', 'Jonah', 4, '1', 'bible'),
(33, 'mic', 'Micah', 7, '3', 'bible'),
(34, 'nam', 'Nahum', 3, '3', 'bible'),
(35, 'hab', 'Habakkuk', 3, '3', 'bible'),
(36, 'zep', 'Zephaniah', 3, '3', 'bible'),
(37, 'hag', 'Haggai', 2, '3', 'bible'),
(38, 'zec', 'Zechariah', 14, '3', 'bible'),
(39, 'mal', 'Malachi', 4, '3', 'bible'),
(41, 'mat', 'Matthew', 28, '2', 'bible'),
(42, 'mrk', 'Mark', 16, '2', 'bible'),
(43, 'luk', 'Luke', 24, '2', 'bible'),
(44, 'jhn', 'John', 21, '3', 'bible'),
(45, 'act', 'Acts', 28, '2', 'bible'),
(46, 'rom', 'Romans', 16, '4', 'bible'),
(47, '1co', '1 Corinthians', 16, '3', 'bible'),
(48, '2co', '2 Corinthians', 13, '3', 'bible'),
(49, 'gal', 'Galatians', 6, '4', 'bible'),
(50, 'eph', 'Ephesians', 6, '4', 'bible'),
(51, 'php', 'Philippians', 4, '4', 'bible'),
(52, 'col', 'Colossians', 4, '4', 'bible'),
(53, '1th', '1 Thessalonians', 5, '3', 'bible'),
(54, '2th', '2 Thessalonians', 3, '3', 'bible'),
(55, '1ti', '1 Timothy', 6, '2', 'bible'),
(56, '2ti', '2 Timothy', 4, '2', 'bible'),
(57, 'tit', 'Titus', 3, '2', 'bible'),
(58, 'phm', 'Philemon', 1, '2', 'bible'),
(59, 'heb', 'Hebrews', 13, '4', 'bible'),
(60, 'jas', 'James', 5, '2', 'bible'),
(61, '1pe', '1 Peter', 5, '3', 'bible'),
(62, '2pe', '2 Peter', 3, '3', 'bible'),
(63, '1jn', '1 John', 5, '3', 'bible'),
(64, '2jn', '2 John', 1, '2', 'bible'),
(65, '3jn', '3 John', 1, '2', 'bible'),
(66, 'jud', 'Jude', 1, '3', 'bible'),
(67, 'rev', 'Revelation', 22, '2', 'bible'),
(75, 'a01', 'A01', 34, '1', 'odb');

-- --------------------------------------------------------

--
-- Table structure for table `ot_chapters`
--

CREATE TABLE `ot_chapters` (
  `chapterID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `memberID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `l2memberID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `l3memberID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `trID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `l2chID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `l3chID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `chapter` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `chunks` text COLLATE utf8_unicode_ci,
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'for other events',
  `l2checked` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'for L2 events',
  `l3checked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'for L3 events'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_checkers_l2`
--

CREATE TABLE `ot_checkers_l2` (
  `l2chID` int(10) UNSIGNED NOT NULL,
  `memberID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `step` enum('none','pray','consume','fst-check','snd-check','keyword-check-l2','peer-review-l2','finished') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pray',
  `currentChapter` int(11) NOT NULL DEFAULT '0',
  `sndCheck` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'second checkers (chapter:memberID,done:int) - done: 0,1,2',
  `peer1Check` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'peer checkers (editors) (chapter:memberID,done:bool)',
  `peer2Check` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'peer checkers (viewers) (chapter:memberID,done:bool)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ot_checkers_l3`
--

CREATE TABLE `ot_checkers_l3` (
  `l3chID` int(10) UNSIGNED NOT NULL,
  `memberID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `step` enum('none','pray','peer-review-l3','peer-edit-l3','finished') NOT NULL DEFAULT 'pray',
  `currentChapter` int(11) NOT NULL DEFAULT '0',
  `peerCheck` text COMMENT 'peer checkers (readers) (chapter:memberID,done:bool)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ot_comments`
--

CREATE TABLE `ot_comments` (
  `cID` int(10) UNSIGNED NOT NULL,
  `memberID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `chapter` int(10) UNSIGNED NOT NULL,
  `chunk` tinyint(3) UNSIGNED NOT NULL,
  `text` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `level` tinyint(3) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_events`
--

CREATE TABLE `ot_events` (
  `eventID` int(10) UNSIGNED NOT NULL,
  `projectID` int(10) UNSIGNED NOT NULL,
  `bookCode` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dateFrom` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateTo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` enum('started','translating','translated','l2_recruit','l2_check','l2_checked','l3_recruit','l3_check','complete') COLLATE utf8_unicode_ci DEFAULT 'started',
  `langInput` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Event is in language input mode',
  `admins` text COLLATE utf8_unicode_ci COMMENT 'facilitators',
  `admins_l2` text COLLATE utf8_unicode_ci COMMENT 'facilitators L2',
  `admins_l3` text COLLATE utf8_unicode_ci COMMENT 'facilitators L3'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_gateway_projects`
--

CREATE TABLE `ot_gateway_projects` (
  `gwProjectID` int(10) UNSIGNED NOT NULL,
  `gwLang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admins` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_keywords`
--

CREATE TABLE `ot_keywords` (
  `kID` int(10) UNSIGNED NOT NULL,
  `memberID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `chapter` int(10) UNSIGNED NOT NULL,
  `chunk` tinyint(3) UNSIGNED NOT NULL,
  `verse` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `indexOrder` tinyint(3) UNSIGNED NOT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_languages`
--

CREATE TABLE `ot_languages` (
  `langID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `langName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `angName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `isGW` tinyint(1) NOT NULL DEFAULT '0',
  `gwLang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `direction` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ltr'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_members`
--

CREATE TABLE `ot_members` (
  `memberID` int(11) UNSIGNED NOT NULL,
  `userName` varchar(255) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `authToken` char(32) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `activationToken` char(32) DEFAULT NULL,
  `resetToken` char(32) DEFAULT NULL,
  `resetDate` timestamp NULL DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `isSuperAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `isDemo` tinyint(1) NOT NULL DEFAULT '0',
  `logins` smallint(6) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ot_members`
--

INSERT INTO `ot_members` (`memberID`, `userName`, `firstName`, `lastName`, `password`, `email`, `authToken`, `active`, `verified`, `blocked`, `activationToken`, `resetToken`, `resetDate`, `isAdmin`, `isSuperAdmin`, `isDemo`, `logins`, `created`) VALUES
(2, 'spec', 'Special', 'User', 'none', 'none', NULL, 1, 1, 0, NULL, NULL, NULL, 0, 0, 0, 0, '2019-06-10 20:52:12');

-- --------------------------------------------------------

--
-- Table structure for table `ot_news`
--

CREATE TABLE `ot_news` (
  `id` int(10) UNSIGNED NOT NULL,
  `category` enum('vmast','vsail','level2','notes','common','questions','words','level3','lang_input') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'common',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('news','faq') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'news',
  `lang` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_profile`
--

CREATE TABLE `ot_profile` (
  `pID` int(10) UNSIGNED NOT NULL,
  `mID` int(10) UNSIGNED NOT NULL,
  `projects` tinytext COLLATE utf8_unicode_ci,
  `proj_lang` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'm1',
  `prefered_roles` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bbl_trans_yrs` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '0, 1, 2, 3',
  `othr_trans_yrs` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '0, 1, 2, 3',
  `bbl_knwlg_degr` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1 (weak) , 2 (moderate) , 3 (strong) , 4 (expert) ',
  `languages` text COLLATE utf8_unicode_ci COMMENT 'array of languages (1-lang code, 2 - fluency (0 (none), 1 (moderate) , 2 (strong) , 3 (fluent) , 4 (native), 5 (expert), 3 - geo_lang_yrs (less than 2, 2-4, 5-7, 8-10)))',
  `mast_evnts` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '0, 1, 2, 3',
  `mast_role` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'translator, facilitator, Level 2 Checking, Level 3 Checking',
  `teamwork` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT 'rarely, some, much, frequently',
  `mast_facilitator` tinyint(1) NOT NULL DEFAULT '0',
  `org` enum('','Other','WA EdServices') COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_person` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `education` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ed_area` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ed_place` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hebrew_knwlg` enum('0','1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '1 - limited, 2 - moderate, 3 - strong, 4 expert',
  `greek_knwlg` enum('0','1','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '1 - limited, 2 - moderate, 3 - strong, 4 expert',
  `church_role` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `complete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ot_profile`
--

INSERT INTO `ot_profile` (`pID`, `mID`, `projects`, `proj_lang`, `avatar`, `prefered_roles`, `bbl_trans_yrs`, `othr_trans_yrs`, `bbl_knwlg_degr`, `languages`, `mast_evnts`, `mast_role`, `teamwork`, `mast_facilitator`, `org`, `ref_person`, `ref_email`, `education`, `ed_area`, `ed_place`, `hebrew_knwlg`, `greek_knwlg`, `church_role`, `complete`) VALUES
(1, 2, '', '', 'm1', '', '1', '1', '1', '', '1', '', '1', 0, '', '', '', '', '', '', '0', '0', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ot_projects`
--

CREATE TABLE `ot_projects` (
  `projectID` int(10) UNSIGNED NOT NULL,
  `gwProjectID` int(10) UNSIGNED NOT NULL,
  `gwLang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `targetLang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bookProject` enum('ulb','sun','odb') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ulb',
  `sourceLangID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sourceBible` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'udb',
  `resLangID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tnLangID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `tqLangID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `twLangID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_sail_dict`
--

CREATE TABLE `ot_sail_dict` (
  `id` int(10) UNSIGNED NOT NULL,
  `word` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ot_sail_dict`
--

INSERT INTO `ot_sail_dict` (`id`, `word`, `symbol`) VALUES
(8982, 'Aaron', ''),
(8983, 'Abaddon', ''),
(8984, 'Abel', ''),
(8985, 'Abiathar', ''),
(8986, 'abide', ''),
(8987, 'Abijah', ''),
(8988, 'Abilene', ''),
(8989, 'ability', ''),
(8990, 'Abiud', ''),
(8991, 'abomination', ''),
(8992, 'about', ''),
(8993, 'above', ''),
(8994, 'Abraham', ''),
(8995, 'Abyss', ''),
(8996, 'according_to', ''),
(8997, 'accuse', ''),
(8998, 'Achaia', ''),
(8999, 'Achaicus', ''),
(9000, 'Achim', ''),
(9001, 'Adam', ''),
(9002, 'Addi', ''),
(9003, 'Admin', ''),
(9004, 'adopt', ''),
(9005, 'adoption', ''),
(9006, 'Adramyttium', ''),
(9007, 'Adriatic_Sea', ''),
(9008, 'adultery', ''),
(9009, 'Aeneas', ''),
(9010, 'Aenon', ''),
(9011, 'afraid', ''),
(9012, 'after', ''),
(9013, 'Agabus', ''),
(9014, 'against', ''),
(9015, 'Agrippa', ''),
(9016, 'Ahaz', ''),
(9017, 'air', ''),
(9018, 'alabaster', ''),
(9019, 'Alexander', ''),
(9020, 'Alexandria', ''),
(9021, 'alive', ''),
(9022, 'all', ''),
(9023, 'allow', ''),
(9024, 'alone', ''),
(9025, 'Alphaeus', ''),
(9026, 'altar', ''),
(9027, 'always', ''),
(9028, 'amazed', ''),
(9029, 'amazing', ''),
(9030, 'ambassador', ''),
(9031, 'amen', ''),
(9032, 'Amminadab', ''),
(9033, 'Amon', ''),
(9034, 'Amos', ''),
(9035, 'Amphipolis', ''),
(9036, 'Ampliatus', ''),
(9037, 'Ananias', ''),
(9038, 'ancestor', ''),
(9039, 'and', ''),
(9040, 'Andrew', ''),
(9041, 'Andronicus', ''),
(9042, 'angel', ''),
(9043, 'anger', ''),
(9044, 'angry', ''),
(9045, 'animal', ''),
(9046, 'Anna', ''),
(9047, 'Annas', ''),
(9048, 'anointed', ''),
(9049, 'another', ''),
(9050, 'Antichrist', ''),
(9051, 'Antioch', ''),
(9052, 'Antipas', ''),
(9053, 'Antipatris', ''),
(9054, 'Apelles', ''),
(9055, 'Apollos', ''),
(9056, 'Apolonia', ''),
(9057, 'apostle', ''),
(9058, 'appear', ''),
(9059, 'Apphia', ''),
(9060, 'appointed', ''),
(9061, 'Appolyon', ''),
(9062, 'Aquila', ''),
(9063, 'Arabia', ''),
(9064, 'Archippus', ''),
(9065, 'Areopagus', ''),
(9066, 'Aretas', ''),
(9067, 'argument', ''),
(9068, 'Arimathea', ''),
(9069, 'arise', ''),
(9070, 'Aristarchus', ''),
(9071, 'Aristobulus', ''),
(9072, 'arm', ''),
(9073, 'armor', ''),
(9074, 'army', ''),
(9075, 'Arni', ''),
(9076, 'around', ''),
(9077, 'Arphaxad', ''),
(9078, 'arrest', ''),
(9079, 'arrow', ''),
(9080, 'Artemas', ''),
(9081, 'Asa', ''),
(9082, 'ascend', ''),
(9083, 'ash', ''),
(9084, 'ashamed', ''),
(9085, 'Asher', ''),
(9086, 'Asher_land', ''),
(9087, 'Asia', ''),
(9088, 'ask', ''),
(9089, 'Assos', ''),
(9090, 'assurance', ''),
(9091, 'Asyncritius', ''),
(9092, 'Athens', ''),
(9093, 'Attalia', ''),
(9094, 'attendant', ''),
(9095, 'author', ''),
(9096, 'authority', ''),
(9097, 'avenge', ''),
(9098, 'awake', ''),
(9099, 'away', ''),
(9100, 'Azor', ''),
(9101, 'Azotus', ''),
(9102, 'Baal', ''),
(9103, 'baby', ''),
(9104, 'Babylon', ''),
(9105, 'backward', ''),
(9106, 'bad', ''),
(9107, 'bag', ''),
(9108, 'Balaam', ''),
(9109, 'Balak', ''),
(9110, 'bank', ''),
(9111, 'baptism', ''),
(9112, 'baptize', ''),
(9113, 'Bar_Jesus_not_Christ', ''),
(9114, 'Barabbas', ''),
(9115, 'Barachiah', ''),
(9116, 'Barak', ''),
(9117, 'Barnabas', ''),
(9118, 'Barsabbas', ''),
(9119, 'Bartholomew', ''),
(9120, 'Bartimaeus', ''),
(9121, 'basket', ''),
(9122, 'battle', ''),
(9123, 'bear', ''),
(9124, 'bear_with', ''),
(9125, 'beast', ''),
(9126, 'beat', ''),
(9127, 'beautiful', ''),
(9128, 'beauty', ''),
(9129, 'because', ''),
(9130, 'beckon', ''),
(9131, 'become_person', ''),
(9132, 'become_thing', ''),
(9133, 'bed', ''),
(9134, 'Beelzebul', ''),
(9135, 'before', ''),
(9136, 'beg', ''),
(9137, 'beginning', ''),
(9138, 'behind', ''),
(9139, 'believe', ''),
(9140, 'Believer', ''),
(9141, 'belt', ''),
(9142, 'Benjamin', ''),
(9143, 'Beor', ''),
(9144, 'Berea', ''),
(9145, 'Bernice', ''),
(9146, 'beside', ''),
(9147, 'best', ''),
(9148, 'Bethany', ''),
(9149, 'Bethesda', ''),
(9150, 'Bethlehem', ''),
(9151, 'Bethphage', ''),
(9152, 'Bethsaida', ''),
(9153, 'betray', ''),
(9154, 'betrayal', ''),
(9155, 'better', ''),
(9156, 'between', ''),
(9157, 'Bible', ''),
(9158, 'big', ''),
(9159, 'bird', ''),
(9160, 'birth', ''),
(9161, 'Bithynia', ''),
(9162, 'bitter', ''),
(9163, 'black', ''),
(9164, 'blaspheme', ''),
(9165, 'blasphemy', ''),
(9166, 'Blastus', ''),
(9167, 'blemish', ''),
(9168, 'bless', ''),
(9169, 'blessed', ''),
(9170, 'blessing', ''),
(9171, 'blind', ''),
(9172, 'blood', ''),
(9173, 'blue', ''),
(9174, 'boast', ''),
(9175, 'boat', ''),
(9176, 'Boaz', ''),
(9177, 'body', ''),
(9178, 'bone', ''),
(9179, 'book', ''),
(9180, 'born', ''),
(9181, 'bottom', ''),
(9182, 'bound', ''),
(9183, 'bow', ''),
(9184, 'bow_arrow', ''),
(9185, 'bowl', ''),
(9186, 'box', ''),
(9187, 'boy', ''),
(9188, 'boys', ''),
(9189, 'branch', ''),
(9190, 'brave', ''),
(9191, 'bread', ''),
(9192, 'break', ''),
(9193, 'breastplate', ''),
(9194, 'breath', ''),
(9195, 'breathe', ''),
(9196, 'bribe', ''),
(9197, 'bride', ''),
(9198, 'bright', ''),
(9199, 'bring', ''),
(9200, 'bronze', ''),
(9201, 'brother', ''),
(9202, 'brothers', ''),
(9203, 'build', ''),
(9204, 'building', ''),
(9205, 'burden', ''),
(9206, 'burn', ''),
(9207, 'burnt', ''),
(9208, 'bury', ''),
(9209, 'but', ''),
(9210, 'buy', ''),
(9211, 'Caesar', ''),
(9212, 'Caesarea', ''),
(9213, 'Caiaphas', ''),
(9214, 'Cain', ''),
(9215, 'Cainan', ''),
(9216, 'call', ''),
(9217, 'camel', ''),
(9218, 'can', ''),
(9219, 'Cana', ''),
(9220, 'Canaan', ''),
(9221, 'Candace', ''),
(9222, 'Capernaum', ''),
(9223, 'Cappadocia', ''),
(9224, 'careful', ''),
(9225, 'carpenter', ''),
(9226, 'Carpus', ''),
(9227, 'carry', ''),
(9228, 'case', ''),
(9229, 'catch', ''),
(9230, 'Cauda', ''),
(9231, 'Cenchrea', ''),
(9232, 'census', ''),
(9233, 'centurion', ''),
(9234, 'Cephas', ''),
(9235, 'ceremony', ''),
(9236, 'chain', ''),
(9237, 'chair', ''),
(9238, 'Chaldea', ''),
(9239, 'change', ''),
(9240, 'chapter', ''),
(9241, 'chariot', ''),
(9242, 'child', ''),
(9243, 'children', ''),
(9244, 'Chios', ''),
(9245, 'Chloe', ''),
(9246, 'choose', ''),
(9247, 'Chorazin', ''),
(9248, 'Christ', ''),
(9249, 'Christian', ''),
(9250, 'church', ''),
(9251, 'Chuza', ''),
(9252, 'Cilicia', ''),
(9253, 'circumcise', ''),
(9254, 'circumcision', ''),
(9255, 'citizen', ''),
(9256, 'Clauda', ''),
(9257, 'Claudia', ''),
(9258, 'Claudius', ''),
(9259, 'clay', ''),
(9260, 'clean', ''),
(9261, 'Clement', ''),
(9262, 'Cleopas', ''),
(9263, 'cloak', ''),
(9264, 'Clopas', ''),
(9265, 'close', ''),
(9266, 'closed', ''),
(9267, 'clothe', ''),
(9268, 'clothing', ''),
(9269, 'cloud', ''),
(9270, 'Cnidus', ''),
(9271, 'cohort', ''),
(9272, 'cold', ''),
(9273, 'color', ''),
(9274, 'Colossae', ''),
(9275, 'come', ''),
(9276, 'come_out', ''),
(9277, 'comfort', ''),
(9278, 'command', ''),
(9279, 'commandment', ''),
(9280, 'compassion', ''),
(9281, 'complete', ''),
(9282, 'condemn', ''),
(9283, 'condemnation', ''),
(9284, 'confession', ''),
(9285, 'confidence', ''),
(9286, 'confuse', ''),
(9287, 'continue', ''),
(9288, 'control', ''),
(9289, 'convert', ''),
(9290, 'Corinth', ''),
(9291, 'Cornelius', ''),
(9292, 'corner', ''),
(9293, 'cornerstone', ''),
(9294, 'correct', ''),
(9295, 'Cosam', ''),
(9296, 'couch', ''),
(9297, 'council', ''),
(9298, 'counted', ''),
(9299, 'country', ''),
(9300, 'countrymen', ''),
(9301, 'countryside', ''),
(9302, 'courage', ''),
(9303, 'courtyard', ''),
(9304, 'covenant', ''),
(9305, 'cover', ''),
(9306, 'covet', ''),
(9307, 'cow', ''),
(9308, 'create', ''),
(9309, 'creation', ''),
(9310, 'Creator', ''),
(9311, 'credit', ''),
(9312, 'Crescan', ''),
(9313, 'Crete', ''),
(9314, 'Crispus', ''),
(9315, 'criticize', ''),
(9316, 'crooked', ''),
(9317, 'cross', ''),
(9318, 'crowd', ''),
(9319, 'crown', ''),
(9320, 'crucify', ''),
(9321, 'crush', ''),
(9322, 'cry', ''),
(9323, 'cup', ''),
(9324, 'curse', ''),
(9325, 'curtain', ''),
(9326, 'Cush', ''),
(9327, 'cushion', ''),
(9328, 'custom', ''),
(9329, 'cut', ''),
(9330, 'cymbal', ''),
(9331, 'Cyprus', ''),
(9332, 'Cyrene', ''),
(9333, 'Dalmanutha', ''),
(9334, 'Dalmatia', ''),
(9335, 'Damaris', ''),
(9336, 'Damascus', ''),
(9337, 'dance', ''),
(9338, 'Daniel', ''),
(9339, 'dark', ''),
(9340, 'daughter', ''),
(9341, 'daughters', ''),
(9342, 'David', ''),
(9343, 'day', ''),
(9344, 'deacon', ''),
(9345, 'dead', ''),
(9346, 'deaf', ''),
(9347, 'death', ''),
(9348, 'Decapolis', ''),
(9349, 'deceive', ''),
(9350, 'deceiver', ''),
(9351, 'deception', ''),
(9352, 'deep', ''),
(9353, 'Demes', ''),
(9354, 'Demetrius', ''),
(9355, 'demon', ''),
(9356, 'denarius', ''),
(9357, 'deny', ''),
(9358, 'depart', ''),
(9359, 'depth', ''),
(9360, 'Derbe', ''),
(9361, 'descend', ''),
(9362, 'descendant', ''),
(9363, 'desert', ''),
(9364, 'deserve', ''),
(9365, 'desire', ''),
(9366, 'destroy', ''),
(9367, 'destruction', ''),
(9368, 'Didymus', ''),
(9369, 'die', ''),
(9370, 'different', ''),
(9371, 'difficult', ''),
(9372, 'dignify', ''),
(9373, 'Dionysius', ''),
(9374, 'Diotrephes', ''),
(9375, 'direction', ''),
(9376, 'dirt', ''),
(9377, 'dirty', ''),
(9378, 'disciple', ''),
(9379, 'discipline', ''),
(9380, 'discourage', ''),
(9381, 'disease', ''),
(9382, 'dish', ''),
(9383, 'disobedience', ''),
(9384, 'disobey', ''),
(9385, 'divide', ''),
(9386, 'division', ''),
(9387, 'divorce', ''),
(9388, 'do', ''),
(9389, 'doctor', ''),
(9390, 'dog', ''),
(9391, 'dominion', ''),
(9392, 'donkey', ''),
(9393, 'door', ''),
(9394, 'Dorcas', ''),
(9395, 'doubt', ''),
(9396, 'dough', ''),
(9397, 'dove', ''),
(9398, 'down', ''),
(9399, 'dragon', ''),
(9400, 'dream', ''),
(9401, 'drink', ''),
(9402, 'drum', ''),
(9403, 'drunk', ''),
(9404, 'Drusilla', ''),
(9405, 'dry', ''),
(9406, 'dust', ''),
(9407, 'dwell', ''),
(9408, 'eagle', ''),
(9409, 'ear', ''),
(9410, 'earn', ''),
(9411, 'earth', ''),
(9412, 'earthquake', ''),
(9413, 'east', ''),
(9414, 'easy', ''),
(9415, 'eat', ''),
(9416, 'Eber', ''),
(9417, 'Egypt', ''),
(9418, 'eight', ''),
(9419, 'Elam', ''),
(9420, 'elder', ''),
(9421, 'Eleazar', ''),
(9422, 'elect', ''),
(9423, 'Eli', ''),
(9424, 'Eliakim', ''),
(9425, 'Eliezer', ''),
(9426, 'Elijah', ''),
(9427, 'Elisha', ''),
(9428, 'Eliud', ''),
(9429, 'Elizabeth', ''),
(9430, 'Elmadam', ''),
(9431, 'Emmaus', ''),
(9432, 'Emmor', ''),
(9433, 'empty', ''),
(9434, 'encourage', ''),
(9435, 'end', ''),
(9436, 'endure', ''),
(9437, 'enemy', ''),
(9438, 'enmity', ''),
(9439, 'Enoch', ''),
(9440, 'Enos', ''),
(9441, 'enter', ''),
(9442, 'envy', ''),
(9443, 'Epaenetus', ''),
(9444, 'Epaphras', ''),
(9445, 'Epaphroditus', ''),
(9446, 'Ephesus', ''),
(9447, 'Ephraim', ''),
(9448, 'Ephraim_city', ''),
(9449, 'Epicurean', ''),
(9450, 'equal', ''),
(9451, 'Er', ''),
(9452, 'Erastus', ''),
(9453, 'Esau', ''),
(9454, 'Esli', ''),
(9455, 'eternal', ''),
(9456, 'eternity', ''),
(9457, 'Ethiopia', ''),
(9458, 'Eubulus', ''),
(9459, 'Eunice', ''),
(9460, 'eunuch', ''),
(9461, 'Euodia', ''),
(9462, 'Euphrates_River', ''),
(9463, 'Eutychus', ''),
(9464, 'evangelist', ''),
(9465, 'Eve', ''),
(9466, 'evening', ''),
(9467, 'everyone', ''),
(9468, 'everything', ''),
(9469, 'everywhere', ''),
(9470, 'exalt', ''),
(9471, 'example', ''),
(9472, 'explain', ''),
(9473, 'explanation', ''),
(9474, 'eye', ''),
(9475, 'fabric', ''),
(9476, 'face', ''),
(9477, 'Fair_Haven', ''),
(9478, 'faith', ''),
(9479, 'faithful', ''),
(9480, 'faithfulness', ''),
(9481, 'fall', ''),
(9482, 'false', ''),
(9483, 'family', ''),
(9484, 'famine', ''),
(9485, 'far', ''),
(9486, 'farewell', ''),
(9487, 'farm', ''),
(9488, 'farmer', ''),
(9489, 'fast_no_eat', ''),
(9490, 'fast_speed', ''),
(9491, 'fat', ''),
(9492, 'fat_animal', ''),
(9493, 'father', ''),
(9494, 'fear', ''),
(9495, 'feast', ''),
(9496, 'Felix', ''),
(9497, 'festival', ''),
(9498, 'few', ''),
(9499, 'field', ''),
(9500, 'fig', ''),
(9501, 'fight', ''),
(9502, 'fill', ''),
(9503, 'find', ''),
(9504, 'finger', ''),
(9505, 'finish', ''),
(9506, 'fire', ''),
(9507, 'first', ''),
(9508, 'fish', ''),
(9509, 'fisherman', ''),
(9510, 'five', ''),
(9511, 'fix', ''),
(9512, 'flesh', ''),
(9513, 'flip', ''),
(9514, 'flood', ''),
(9515, 'flour', ''),
(9516, 'flower', ''),
(9517, 'flute', ''),
(9518, 'fly', ''),
(9519, 'follow', ''),
(9520, 'food', ''),
(9521, 'fool', ''),
(9522, 'foot', ''),
(9523, 'for', ''),
(9524, 'foreigner', ''),
(9525, 'foreknowledge', ''),
(9526, 'forest', ''),
(9527, 'forgive', ''),
(9528, 'forgiveness', ''),
(9529, 'Fortunatus', ''),
(9530, 'forward', ''),
(9531, 'foundation', ''),
(9532, 'four', ''),
(9533, 'fox', ''),
(9534, 'fragrant', ''),
(9535, 'free', ''),
(9536, 'free_no_cost', ''),
(9537, 'Freedmen', ''),
(9538, 'freedom', ''),
(9539, 'friend', ''),
(9540, 'frog', ''),
(9541, 'from', ''),
(9542, 'fruit', ''),
(9543, 'fulfill', ''),
(9544, 'full', ''),
(9545, 'futile', ''),
(9546, 'future', ''),
(9547, 'Gabriel', ''),
(9548, 'Gad', ''),
(9549, 'Gadara', ''),
(9550, 'gain', ''),
(9551, 'Gaius', ''),
(9552, 'Galatia', ''),
(9553, 'Galilee', ''),
(9554, 'Gallio', ''),
(9555, 'Gamaliel', ''),
(9556, 'gate', ''),
(9557, 'gathered_people', ''),
(9558, 'gathered_things', ''),
(9559, 'Gaza', ''),
(9560, 'generation', ''),
(9561, 'Gennesaret', ''),
(9562, 'gentile', ''),
(9563, 'gentle', ''),
(9564, 'gentleness', ''),
(9565, 'Gerasenes', ''),
(9566, 'Gethsemane', ''),
(9567, 'Gideon', ''),
(9568, 'gift', ''),
(9569, 'girl', ''),
(9570, 'girls', ''),
(9571, 'give', ''),
(9572, 'glass', ''),
(9573, 'glorify', ''),
(9574, 'glory', ''),
(9575, 'gluttony', ''),
(9576, 'go', ''),
(9577, 'go_down', ''),
(9578, 'goat', ''),
(9579, 'God', ''),
(9580, 'godly', ''),
(9581, 'Gog', ''),
(9582, 'gold', ''),
(9583, 'Golgotha', ''),
(9584, 'Gomorrah', ''),
(9585, 'gong', ''),
(9586, 'good', ''),
(9587, 'good_news', ''),
(9588, 'gospel', ''),
(9589, 'governor', ''),
(9590, 'grace', ''),
(9591, 'grain', ''),
(9592, 'grape', ''),
(9593, 'grass', ''),
(9594, 'grateful', ''),
(9595, 'gratitude', ''),
(9596, 'grave', ''),
(9597, 'great', ''),
(9598, 'Greece', ''),
(9599, 'greed', ''),
(9600, 'green', ''),
(9601, 'greeting', ''),
(9602, 'grieve', ''),
(9603, 'grind', ''),
(9604, 'groom', ''),
(9605, 'ground', ''),
(9606, 'ground_soil', ''),
(9607, 'grow', ''),
(9608, 'growth', ''),
(9609, 'guard', ''),
(9610, 'guilt', ''),
(9611, 'guilty', ''),
(9612, 'Hagar', ''),
(9613, 'hail', ''),
(9614, 'hail_storm', ''),
(9615, 'hair', ''),
(9616, 'half', ''),
(9617, 'Hamor', ''),
(9618, 'hand', ''),
(9619, 'Hannah', ''),
(9620, 'happy', ''),
(9621, 'Haran', ''),
(9622, 'hard', ''),
(9623, 'harlot', ''),
(9624, 'harp', ''),
(9625, 'harsh', ''),
(9626, 'harvest', ''),
(9627, 'harvester', ''),
(9628, 'hate', ''),
(9629, 'have', ''),
(9630, 'have_to', ''),
(9631, 'head', ''),
(9632, 'heal', ''),
(9633, 'healer', ''),
(9634, 'health', ''),
(9635, 'healthy', ''),
(9636, 'hear', ''),
(9637, 'heart', ''),
(9638, 'heat', ''),
(9639, 'heaven', ''),
(9640, 'heavy', ''),
(9641, 'Hebrew', ''),
(9642, 'hedge', ''),
(9643, 'height', ''),
(9644, 'heir', ''),
(9645, 'Heli', ''),
(9646, 'hell', ''),
(9647, 'help', ''),
(9648, 'helper', ''),
(9649, 'here', ''),
(9650, 'Hermas', ''),
(9651, 'Hermes', ''),
(9652, 'Hermes_idol', ''),
(9653, 'Hermogenes', ''),
(9654, 'Herod', ''),
(9655, 'Herodians', ''),
(9656, 'Herodias', ''),
(9657, 'Herodion', ''),
(9658, 'Hezekiah', ''),
(9659, 'Hezron', ''),
(9660, 'hide', ''),
(9661, 'Hierapolis', ''),
(9662, 'hill', ''),
(9663, 'hire', ''),
(9664, 'hit', ''),
(9665, 'hole', ''),
(9666, 'holy', ''),
(9667, 'honey', ''),
(9668, 'honor', ''),
(9669, 'hope', ''),
(9670, 'horn', ''),
(9671, 'horse', ''),
(9672, 'hosanna', ''),
(9673, 'Hosea', ''),
(9674, 'hot', ''),
(9675, 'hour', ''),
(9676, 'house', ''),
(9677, 'how', ''),
(9678, 'how_long', ''),
(9679, 'human_nature', ''),
(9680, 'humble', ''),
(9681, 'humiliate', ''),
(9682, 'humility', ''),
(9683, 'hungry', ''),
(9684, 'hurt', ''),
(9685, 'husband', ''),
(9686, 'Hymenaeus', ''),
(9687, 'hymn', ''),
(9688, 'hypocrite', ''),
(9689, 'I', ''),
(9690, 'Iconium', ''),
(9691, 'idol', ''),
(9692, 'Idumea', ''),
(9693, 'if', ''),
(9694, 'ignorance', ''),
(9695, 'ignorant', ''),
(9696, 'Illyricum', ''),
(9697, 'immeasurable', ''),
(9698, 'immediately', ''),
(9699, 'important', ''),
(9700, 'impossible', ''),
(9701, 'imprisoned', ''),
(9702, 'impure', ''),
(9703, 'in', ''),
(9704, 'in_front', ''),
(9705, 'incense', ''),
(9706, 'inheritance', ''),
(9707, 'insect', ''),
(9708, 'inside', ''),
(9709, 'insist', ''),
(9710, 'insult', ''),
(9711, 'iron', ''),
(9712, 'Isaac', ''),
(9713, 'Isaiah', ''),
(9714, 'island', ''),
(9715, 'Israel', ''),
(9716, 'Issachar', ''),
(9717, 'Italy', ''),
(9718, 'Ituraea', ''),
(9719, 'Jacob', ''),
(9720, 'Jacob(NT)', ''),
(9721, 'Jairus', ''),
(9722, 'Jambres', ''),
(9723, 'James', ''),
(9724, 'James_the_Disciple', ''),
(9725, 'Jannai', ''),
(9726, 'Jannes', ''),
(9727, 'jar', ''),
(9728, 'Jared', ''),
(9729, 'Jason', ''),
(9730, 'Jechoniah', ''),
(9731, 'Jehoshaphat', ''),
(9732, 'Jephthah', ''),
(9733, 'Jeremiah', ''),
(9734, 'Jericho', ''),
(9735, 'Jerusalem', ''),
(9736, 'Jesse', ''),
(9737, 'Jesus', ''),
(9738, 'Jesus_not_Christ', ''),
(9739, 'Jew', ''),
(9740, 'Jewish', ''),
(9741, 'Jezebel', ''),
(9742, 'Joanan', ''),
(9743, 'Joanna', ''),
(9744, 'Job', ''),
(9745, 'Joda', ''),
(9746, 'Joel', ''),
(9747, 'John', ''),
(9748, 'John_the_Baptist', ''),
(9749, 'John_the_Disciple', ''),
(9750, 'Jonah', ''),
(9751, 'Jonah_Simons_father', ''),
(9752, 'Jonam', ''),
(9753, 'Joppa', ''),
(9754, 'Joram', ''),
(9755, 'Jordan_River', ''),
(9756, 'Jorim', ''),
(9757, 'Joseph', ''),
(9758, 'Joseph(NT)', ''),
(9759, 'Joses', ''),
(9760, 'Joshua', ''),
(9761, 'Josiah', ''),
(9762, 'Jotham', ''),
(9763, 'Jothan', ''),
(9764, 'journey', ''),
(9765, 'joy', ''),
(9766, 'Juda', ''),
(9767, 'Judah', ''),
(9768, 'Judas', ''),
(9769, 'Judas_Iscariot', ''),
(9770, 'Judas_not_Iscariot', ''),
(9771, 'Jude', ''),
(9772, 'Judea', ''),
(9773, 'judge', ''),
(9774, 'judgment', ''),
(9775, 'Julia', ''),
(9776, 'Julius', ''),
(9777, 'jump', ''),
(9778, 'Junia', ''),
(9779, 'justice', ''),
(9780, 'justify', ''),
(9781, 'Justus', ''),
(9782, 'keep', ''),
(9783, 'key', ''),
(9784, 'Kidron_Valley', ''),
(9785, 'kill', ''),
(9786, 'kind_nice', ''),
(9787, 'kind_same', ''),
(9788, 'kindness', ''),
(9789, 'king', ''),
(9790, 'kingdom', ''),
(9791, 'Kish', ''),
(9792, 'kiss', ''),
(9793, 'kneel', ''),
(9794, 'knife', ''),
(9795, 'knock', ''),
(9796, 'knot', ''),
(9797, 'know', ''),
(9798, 'knowledge', ''),
(9799, 'Korah', ''),
(9800, 'lake', ''),
(9801, 'Lamech', ''),
(9802, 'lamp', ''),
(9803, 'lampstand', ''),
(9804, 'land', ''),
(9805, 'language', ''),
(9806, 'Laodicea', ''),
(9807, 'Lasea', ''),
(9808, 'last', ''),
(9809, 'late', ''),
(9810, 'later', ''),
(9811, 'Latin', ''),
(9812, 'laugh', ''),
(9813, 'laughter', ''),
(9814, 'law', ''),
(9815, 'lawful', ''),
(9816, 'lawlessness', ''),
(9817, 'Lazarus', ''),
(9818, 'lead', ''),
(9819, 'lead_astray', ''),
(9820, 'leader', ''),
(9821, 'leaf', ''),
(9822, 'leap', ''),
(9823, 'learn', ''),
(9824, 'lease', ''),
(9825, 'least', ''),
(9826, 'leather', ''),
(9827, 'leave', ''),
(9828, 'leaven', ''),
(9829, 'left', ''),
(9830, 'leg', ''),
(9831, 'Legion', ''),
(9832, 'length', ''),
(9833, 'leopard', ''),
(9834, 'leprosy', ''),
(9835, 'letter', ''),
(9836, 'level', ''),
(9837, 'Levi', ''),
(9838, 'Levi_Matthew', ''),
(9839, 'Levite', ''),
(9840, 'Libya', ''),
(9841, 'lie', ''),
(9842, 'lie_down', ''),
(9843, 'life', ''),
(9844, 'lift', ''),
(9845, 'light', ''),
(9846, 'lightning', ''),
(9847, 'like', ''),
(9848, 'linen', ''),
(9849, 'Linus', ''),
(9850, 'lion', ''),
(9851, 'live', ''),
(9852, 'loaf', ''),
(9853, 'locust', ''),
(9854, 'Lois', ''),
(9855, 'longsuffering', ''),
(9856, 'looks_like', ''),
(9857, 'lord', ''),
(9858, 'lost', ''),
(9859, 'lot', ''),
(9860, 'Lot', ''),
(9861, 'lots', ''),
(9862, 'loud', ''),
(9863, 'love', ''),
(9864, 'lower_adj.', ''),
(9865, 'lower_verb', ''),
(9866, 'Lucius', ''),
(9867, 'Luke', ''),
(9868, 'lunatic', ''),
(9869, 'lust', ''),
(9870, 'Lycaonia', ''),
(9871, 'Lycia', ''),
(9872, 'Lydda', ''),
(9873, 'Lydia', ''),
(9874, 'Lysanias', ''),
(9875, 'Lysias', ''),
(9876, 'Lystra', ''),
(9877, 'Maath', ''),
(9878, 'Macedonia', ''),
(9879, 'Magadan', ''),
(9880, 'magician', ''),
(9881, 'Magog', ''),
(9882, 'Mahalaleel', ''),
(9883, 'make', ''),
(9884, 'Malchus', ''),
(9885, 'Malta', ''),
(9886, 'man', ''),
(9887, 'Manaen', ''),
(9888, 'manage', ''),
(9889, 'Manasseh', ''),
(9890, 'manna', ''),
(9891, 'many', ''),
(9892, 'Mark', ''),
(9893, 'market_place', ''),
(9894, 'marriage', ''),
(9895, 'Martha', ''),
(9896, 'Mary', ''),
(9897, 'Mary_Magdalene', ''),
(9898, 'Mary_Mother_of_Jesus', ''),
(9899, 'master', ''),
(9900, 'Mattatha', ''),
(9901, 'Mattathias', ''),
(9902, 'Matthan', ''),
(9903, 'Matthat', ''),
(9904, 'Matthew', ''),
(9905, 'Matthias', ''),
(9906, 'mattress', ''),
(9907, 'mature', ''),
(9908, 'me', ''),
(9909, 'meal', ''),
(9910, 'meaning', ''),
(9911, 'measure', ''),
(9912, 'Media', ''),
(9913, 'Megiddo', ''),
(9914, 'Melchi', ''),
(9915, 'Melchizedek', ''),
(9916, 'Melea', ''),
(9917, 'member', ''),
(9918, 'Menna', ''),
(9919, 'mercy', ''),
(9920, 'Mesopotamia', ''),
(9921, 'message', ''),
(9922, 'messenger', ''),
(9923, 'Messiah', ''),
(9924, 'metal', ''),
(9925, 'Methuselah', ''),
(9926, 'Michael', ''),
(9927, 'Midian', ''),
(9928, 'Miletus', ''),
(9929, 'milk', ''),
(9930, 'million', ''),
(9931, 'mind', ''),
(9932, 'mine', 'm'),
(9933, 'miracle', ''),
(9934, 'Miriam', ''),
(9935, 'mirror', ''),
(9936, 'Mitylene', ''),
(9937, 'Mnason', ''),
(9938, 'mock', ''),
(9939, 'Molech', ''),
(9940, 'money', ''),
(9941, 'month', ''),
(9942, 'moon', ''),
(9943, 'more', ''),
(9944, 'morning', ''),
(9945, 'Moses', ''),
(9946, 'most', ''),
(9947, 'mother', ''),
(9948, 'Mount_of_Olives', ''),
(9949, 'Mount_Sinai', ''),
(9950, 'Mount_Zion', ''),
(9951, 'mountain', ''),
(9952, 'mouth', ''),
(9953, 'move', ''),
(9954, 'much', ''),
(9955, 'multitude', ''),
(9956, 'murderer', ''),
(9957, 'mustard', ''),
(9958, 'mute', ''),
(9959, 'my', 'm'),
(9960, 'Myra', ''),
(9961, 'myrrh', ''),
(9962, 'Mysia', ''),
(9963, 'mystery', ''),
(9964, 'Naaman', ''),
(9965, 'Naggai', ''),
(9966, 'Nahor', ''),
(9967, 'Nahshon', ''),
(9968, 'Nahum', ''),
(9969, 'nail', ''),
(9970, 'Nain', ''),
(9971, 'name', ''),
(9972, 'Naphtali', ''),
(9973, 'Narcius', ''),
(9974, 'Nathan', ''),
(9975, 'Nathaniel', ''),
(9976, 'nation', ''),
(9977, 'Nazareth', ''),
(9978, 'near', ''),
(9979, 'neck', ''),
(9980, 'need', ''),
(9981, 'needle', ''),
(9982, 'neighbor', ''),
(9983, 'Neopolis', ''),
(9984, 'Nereus', ''),
(9985, 'Neri', ''),
(9986, 'net', ''),
(9987, 'new', ''),
(9988, 'news', ''),
(9989, 'next', ''),
(9990, 'Nicanor', ''),
(9991, 'Nicodemus', ''),
(9992, 'Nicolaus', ''),
(9993, 'Nicopolis', ''),
(9994, 'night', ''),
(9995, 'nine', ''),
(9996, 'Nineveh', ''),
(9997, 'no', ''),
(9998, 'Noah', ''),
(9999, 'noise', ''),
(10000, 'north', ''),
(10001, 'nose', ''),
(10002, 'not', ''),
(10003, 'now', ''),
(10004, 'number', ''),
(10005, 'Nympha', ''),
(10006, 'Obed', ''),
(10007, 'obedience', ''),
(10008, 'obey', ''),
(10009, 'ocean', ''),
(10010, 'offering', ''),
(10011, 'oil', ''),
(10012, 'old', ''),
(10013, 'olive', ''),
(10014, 'Olympus', ''),
(10015, 'on', ''),
(10016, 'on_top_of', ''),
(10017, 'one', ''),
(10018, 'Onesimus', ''),
(10019, 'Onesiphorus', ''),
(10020, 'only', ''),
(10021, 'open', ''),
(10022, 'oppose', ''),
(10023, 'or', ''),
(10024, 'order', ''),
(10025, 'other', ''),
(10026, 'our', 'w'),
(10027, 'ours', 'w'),
(10028, 'out', ''),
(10029, 'outside', ''),
(10030, 'over', ''),
(10031, 'owe', ''),
(10032, 'own', ''),
(10033, 'ox', ''),
(10034, 'pain', ''),
(10035, 'Pamphylia', ''),
(10036, 'Paphos', ''),
(10037, 'parable', ''),
(10038, 'paralyze', ''),
(10039, 'Parmenas', ''),
(10040, 'part', ''),
(10041, 'Parthia', ''),
(10042, 'party', ''),
(10043, 'pass', ''),
(10044, 'passion', ''),
(10045, 'Passover', ''),
(10046, 'past', ''),
(10047, 'pastor', ''),
(10048, 'Patara', ''),
(10049, 'path', ''),
(10050, 'patience', ''),
(10051, 'patient', ''),
(10052, 'Patmos', ''),
(10053, 'Patrobas', ''),
(10054, 'pattern', ''),
(10055, 'Paul', ''),
(10056, 'pavement', ''),
(10057, 'peace', ''),
(10058, 'Peleg', ''),
(10059, 'pen', ''),
(10060, 'pentecost', ''),
(10061, 'Pentecost', ''),
(10062, 'people', ''),
(10063, 'perceive', ''),
(10064, 'Perez', ''),
(10065, 'perfect', ''),
(10066, 'perfume', ''),
(10067, 'Perga', ''),
(10068, 'Pergamun', ''),
(10069, 'permission', ''),
(10070, 'permit', ''),
(10071, 'persecute', ''),
(10072, 'persecution', ''),
(10073, 'Persis', ''),
(10074, 'person', ''),
(10075, 'Phanuel', ''),
(10076, 'Pharaoh', ''),
(10077, 'Pharisee', ''),
(10078, 'Philadelphia', ''),
(10079, 'Philemon', ''),
(10080, 'Philetus', ''),
(10081, 'Philip', ''),
(10082, 'Philippi', ''),
(10083, 'Philologus', ''),
(10084, 'philosopher', ''),
(10085, 'Phlegon', ''),
(10086, 'Phoebe', ''),
(10087, 'Phoenicia', ''),
(10088, 'Phoenix', ''),
(10089, 'Phrygia', ''),
(10090, 'Phygelus', ''),
(10091, 'pig', ''),
(10092, 'pigeon', ''),
(10093, 'Pilate', ''),
(10094, 'pillar', ''),
(10095, 'pillow', ''),
(10096, 'Pisidia', ''),
(10097, 'plan', ''),
(10098, 'plant', ''),
(10099, 'plate', ''),
(10100, 'platter', ''),
(10101, 'plow', ''),
(10102, 'Pontus', ''),
(10103, 'poor', ''),
(10104, 'porch', ''),
(10105, 'Porcius', ''),
(10106, 'possible', ''),
(10107, 'pour', ''),
(10108, 'power', ''),
(10109, 'praise', ''),
(10110, 'pray', ''),
(10111, 'prayer', ''),
(10112, 'preach', ''),
(10113, 'preacher', ''),
(10114, 'preaching', ''),
(10115, 'precious', ''),
(10116, 'pregnant', ''),
(10117, 'prepare', ''),
(10118, 'press', ''),
(10119, 'pretend', ''),
(10120, 'prevail', ''),
(10121, 'pride', ''),
(10122, 'priest', ''),
(10123, 'prince', ''),
(10124, 'priority', ''),
(10125, 'Priscilla', ''),
(10126, 'prison', ''),
(10127, 'prisoner', ''),
(10128, 'Prochorus', ''),
(10129, 'proconsul', ''),
(10130, 'profit', ''),
(10131, 'promise', ''),
(10132, 'prophesy', ''),
(10133, 'prophet', ''),
(10134, 'prostitute', ''),
(10135, 'proud', ''),
(10136, 'proverb', ''),
(10137, 'Psalm', ''),
(10138, 'Ptolemais', ''),
(10139, 'Publius', ''),
(10140, 'Pudens', ''),
(10141, 'pure', ''),
(10142, 'purple', ''),
(10143, 'purpose', ''),
(10144, 'put', ''),
(10145, 'Put', ''),
(10146, 'Puteoli', ''),
(10147, 'Pyrrhus', ''),
(10148, 'Quartus', ''),
(10149, 'queen', ''),
(10150, 'questioned', ''),
(10151, 'quiet', ''),
(10152, 'Quirinius', ''),
(10153, 'Rachel', ''),
(10154, 'Rahab', ''),
(10155, 'rain', ''),
(10156, 'rainbow', ''),
(10157, 'Ram', ''),
(10158, 'Ramah', ''),
(10159, 'read', ''),
(10160, 'reason', ''),
(10161, 'Rebekah', ''),
(10162, 'rebellion', ''),
(10163, 'rebuke', ''),
(10164, 'receive', ''),
(10165, 'reckon', ''),
(10166, 'reconcile', ''),
(10167, 'red', ''),
(10168, 'redeem', ''),
(10169, 'redemption', ''),
(10170, 'reed', ''),
(10171, 'Rehoboam', ''),
(10172, 'reject', ''),
(10173, 'relative', ''),
(10174, 'religion', ''),
(10175, 'remain', ''),
(10176, 'remember', ''),
(10177, 'repeat', ''),
(10178, 'repent', ''),
(10179, 'repentance', ''),
(10180, 'report', ''),
(10181, 'rescue', ''),
(10182, 'rest', ''),
(10183, 'result', ''),
(10184, 'resurrect', ''),
(10185, 'resurrection', ''),
(10186, 'Reu', ''),
(10187, 'Reuben', ''),
(10188, 'reveal', ''),
(10189, 'revenge', ''),
(10190, 'revile', ''),
(10191, 'reward', ''),
(10192, 'Rhegium', ''),
(10193, 'Rhesa', ''),
(10194, 'Rhoda', ''),
(10195, 'Rhodes', ''),
(10196, 'right', ''),
(10197, 'right_time', ''),
(10198, 'righteous', ''),
(10199, 'righteous_person', ''),
(10200, 'righteousness', ''),
(10201, 'ring', ''),
(10202, 'ripe', ''),
(10203, 'ripen', ''),
(10204, 'river', ''),
(10205, 'road', ''),
(10206, 'robber', ''),
(10207, 'rock', ''),
(10208, 'Rome', ''),
(10209, 'room', ''),
(10210, 'rooster', ''),
(10211, 'root', ''),
(10212, 'rough', ''),
(10213, 'Rufus', ''),
(10214, 'ruler', ''),
(10215, 'run', ''),
(10216, 'Ruth', ''),
(10217, 'sabbath', ''),
(10218, 'sacrifice', ''),
(10219, 'sad', ''),
(10220, 'Saducee', ''),
(10221, 'said', ''),
(10222, 'sail', ''),
(10223, 'saint', ''),
(10224, 'Salamis', ''),
(10225, 'Salathiel', ''),
(10226, 'Salim', ''),
(10227, 'Salmon', ''),
(10228, 'Salmone', ''),
(10229, 'Salome', ''),
(10230, 'salt', ''),
(10231, 'salvation', ''),
(10232, 'Samaria', ''),
(10233, 'Samaritan', ''),
(10234, 'same', ''),
(10235, 'Samos', ''),
(10236, 'Samothrace', ''),
(10237, 'Samson', ''),
(10238, 'Samuel', ''),
(10239, 'sanctuary', ''),
(10240, 'sand', ''),
(10241, 'Sapphira', ''),
(10242, 'Sarah', ''),
(10243, 'Sardis', ''),
(10244, 'Satan', ''),
(10245, 'Saul', ''),
(10246, 'save', ''),
(10247, 'savior', ''),
(10248, 'scatter', ''),
(10249, 'Sceva', ''),
(10250, 'scorpion', ''),
(10251, 'scribe', ''),
(10252, 'Scripture', ''),
(10253, 'Scythia', ''),
(10254, 'sea', ''),
(10255, 'Sea_of_Galilee', ''),
(10256, 'Sea_of_Reeds', ''),
(10257, 'Sea_of_Tiberias', ''),
(10258, 'seal', ''),
(10259, 'sealed', ''),
(10260, 'search', ''),
(10261, 'secret', ''),
(10262, 'sect', ''),
(10263, 'Secundus', ''),
(10264, 'see', ''),
(10265, 'seed', ''),
(10266, 'Seleucia', ''),
(10267, 'self', ''),
(10268, 'sell', ''),
(10269, 'Semien', ''),
(10270, 'send', ''),
(10271, 'sensuality', ''),
(10272, 'separate', ''),
(10273, 'Sergius', ''),
(10274, 'Serug', ''),
(10275, 'servant', ''),
(10276, 'serve', ''),
(10277, 'Seth', ''),
(10278, 'seven', ''),
(10279, 'sew', ''),
(10280, 'sex', ''),
(10281, 'sexual_desire', ''),
(10282, 'shade', ''),
(10283, 'shake', ''),
(10284, 'shame', ''),
(10285, 'share', ''),
(10286, 'Sharon', ''),
(10287, 'sharp', ''),
(10288, 'shave', ''),
(10289, 'Shealtiel', ''),
(10290, 'Shechem', ''),
(10291, 'sheep', ''),
(10292, 'Shelah', ''),
(10293, 'Shem', ''),
(10294, 'Sheol', ''),
(10295, 'shepherd', ''),
(10296, 'shield', ''),
(10297, 'shoe', ''),
(10298, 'shout', ''),
(10299, 'show', ''),
(10300, 'sick', ''),
(10301, 'side', ''),
(10302, 'Sidon', ''),
(10303, 'sigh', ''),
(10304, 'sign', ''),
(10305, 'Silas', ''),
(10306, 'silence', ''),
(10307, 'Siloam', ''),
(10308, 'Silvanus', ''),
(10309, 'silver', ''),
(10310, 'Simeon', ''),
(10311, 'Simon', ''),
(10312, 'Simon_Jesus_brother', ''),
(10313, 'Simon_of_Cyrene', ''),
(10314, 'Simon_Peter', ''),
(10315, 'Simon_the_Canaanite', ''),
(10316, 'Simon_the_Leper', ''),
(10317, 'sin', ''),
(10318, 'sinful', ''),
(10319, 'sing', ''),
(10320, 'sinner', ''),
(10321, 'sister', ''),
(10322, 'sisters', ''),
(10323, 'sit', ''),
(10324, 'six', ''),
(10325, 'skull', ''),
(10326, 'sky', ''),
(10327, 'slave', ''),
(10328, 'sleep', ''),
(10329, 'slow', ''),
(10330, 'slow', ''),
(10331, 'small', ''),
(10332, 'smaller', ''),
(10333, 'smallest', ''),
(10334, 'smell', ''),
(10335, 'smoke', ''),
(10336, 'smooth', ''),
(10337, 'Smyrna', ''),
(10338, 'snake', ''),
(10339, 'snow', ''),
(10340, 'Sodom', ''),
(10341, 'soft', ''),
(10342, 'soil', ''),
(10343, 'sojourner', ''),
(10344, 'soldier', ''),
(10345, 'Solomon', ''),
(10346, 'some', ''),
(10347, 'son', ''),
(10348, 'Son_of_Man', ''),
(10349, 'song', ''),
(10350, 'sons', ''),
(10351, 'Sopater', ''),
(10352, 'sorcery', ''),
(10353, 'Sosipater', ''),
(10354, 'Sosthenes', ''),
(10355, 'soul', ''),
(10356, 'sound', ''),
(10357, 'south', ''),
(10358, 'sow', ''),
(10359, 'sower', ''),
(10360, 'Spain', ''),
(10361, 'speak', ''),
(10362, 'spend', ''),
(10363, 'spice', ''),
(10364, 'spirit', ''),
(10365, 'spit', ''),
(10366, 'split', ''),
(10367, 'sponge', ''),
(10368, 'spot', ''),
(10369, 'spy', ''),
(10370, 'Stachys', ''),
(10371, 'staff', ''),
(10372, 'stair', ''),
(10373, 'stand', ''),
(10374, 'star', ''),
(10375, 'start', ''),
(10376, 'stay', ''),
(10377, 'steal', ''),
(10378, 'stem', ''),
(10379, 'Stephanas', ''),
(10380, 'Stephen', ''),
(10381, 'stern', ''),
(10382, 'stern_words', ''),
(10383, 'stewardship', ''),
(10384, 'stick', ''),
(10385, 'Stoic', ''),
(10386, 'stomach', ''),
(10387, 'stop', ''),
(10388, 'storehouse', ''),
(10389, 'storm', ''),
(10390, 'story', ''),
(10391, 'straight', ''),
(10392, 'stranger', ''),
(10393, 'strangled', ''),
(10394, 'stream', ''),
(10395, 'stretch', ''),
(10396, 'string', ''),
(10397, 'strong', ''),
(10398, 'stumble', ''),
(10399, 'stumbling_block', ''),
(10400, 'suffer', ''),
(10401, 'suffering', ''),
(10402, 'summer', ''),
(10403, 'sun', ''),
(10404, 'sundown', ''),
(10405, 'Susanna', ''),
(10406, 'sweet', ''),
(10407, 'sword', ''),
(10408, 'synagogue', ''),
(10409, 'Syntyche', ''),
(10410, 'Syracuse', ''),
(10411, 'Syria', ''),
(10412, 'tabernacle', ''),
(10413, 'table', ''),
(10414, 'tail', ''),
(10415, 'take', ''),
(10416, 'Tamar', ''),
(10417, 'Tarsus', ''),
(10418, 'taste', ''),
(10419, 'tax', ''),
(10420, 'tax_collector', ''),
(10421, 'teach', ''),
(10422, 'teacher', ''),
(10423, 'teaching', ''),
(10424, 'teeth', ''),
(10425, 'temple', ''),
(10426, 'tempt', ''),
(10427, 'temptation', ''),
(10428, 'ten', ''),
(10429, 'tent', ''),
(10430, 'Terah', ''),
(10431, 'Tertius', ''),
(10432, 'Tertullus', ''),
(10433, 'test', ''),
(10434, 'testimony', ''),
(10435, 'Thaddaeus', ''),
(10436, 'thank', ''),
(10437, 'that', ''),
(10438, 'them', ''),
(10439, 'Theophilus', ''),
(10440, 'therefore', ''),
(10441, 'Thessalonica', ''),
(10442, 'Theudas', ''),
(10443, 'they', ''),
(10444, 'thief', ''),
(10445, 'thigh', ''),
(10446, 'thing', ''),
(10447, 'think', ''),
(10448, 'think_opinion', ''),
(10449, 'think_wonder', ''),
(10450, 'thirst', ''),
(10451, 'thirsty', ''),
(10452, 'this', ''),
(10453, 'Thomas', ''),
(10454, 'thorn', ''),
(10455, 'thought', ''),
(10456, 'thousand', ''),
(10457, 'three', ''),
(10458, 'threshing', ''),
(10459, 'threshing_floor', ''),
(10460, 'throne', ''),
(10461, 'through', ''),
(10462, 'throw', ''),
(10463, 'thunder', ''),
(10464, 'Thyatira', ''),
(10465, 'Tiberias', ''),
(10466, 'Tiberius', ''),
(10467, 'tie', ''),
(10468, 'Timaeus', ''),
(10469, 'time', ''),
(10470, 'times', ''),
(10471, 'Timon', ''),
(10472, 'Timothy', ''),
(10473, 'tithe', ''),
(10474, 'Titus', ''),
(10475, 'to', ''),
(10476, 'to_clothe', ''),
(10477, 'to_plant', ''),
(10478, 'together_people', ''),
(10479, 'together_things', ''),
(10480, 'tomb', ''),
(10481, 'tongue', ''),
(10482, 'tool', ''),
(10483, 'touch', ''),
(10484, 'tower', ''),
(10485, 'Trachonitis', ''),
(10486, 'transfiguration', ''),
(10487, 'transfigure', ''),
(10488, 'travel', ''),
(10489, 'tree', ''),
(10490, 'trial', ''),
(10491, 'tribe', ''),
(10492, 'tribulation', ''),
(10493, 'trip', ''),
(10494, 'triumph', ''),
(10495, 'Troas', ''),
(10496, 'Trophimus', ''),
(10497, 'trouble', ''),
(10498, 'true', ''),
(10499, 'trumpet', ''),
(10500, 'trust', ''),
(10501, 'truth', ''),
(10502, 'try', ''),
(10503, 'Tryphaena', ''),
(10504, 'Tryphosa', ''),
(10505, 'turn', ''),
(10506, 'twin', ''),
(10507, 'two', ''),
(10508, 'Tychicus', ''),
(10509, 'type', ''),
(10510, 'Tyrannus', ''),
(10511, 'Tyre', ''),
(10512, 'unbelief', ''),
(10513, 'under', ''),
(10514, 'understand', ''),
(10515, 'understanding', ''),
(10516, 'unity', ''),
(10517, 'unleavened', ''),
(10518, 'unrighteous', ''),
(10519, 'unrighteousness', ''),
(10520, 'untie', ''),
(10521, 'until', ''),
(10522, 'up', ''),
(10523, 'Urbanus', ''),
(10524, 'Uriah', ''),
(10525, 'us', ''),
(10526, 'use', ''),
(10527, 'useful', ''),
(10528, 'useless', ''),
(10529, 'Uzziah', ''),
(10530, 'valley', ''),
(10531, 'value', ''),
(10532, 'vendor', ''),
(10533, 'vengeance', ''),
(10534, 'very', ''),
(10535, 'victory', ''),
(10536, 'village', ''),
(10537, 'vine', ''),
(10538, 'vineyard', ''),
(10539, 'virgin', ''),
(10540, 'vision', ''),
(10541, 'visit', ''),
(10542, 'voice', ''),
(10543, 'waist', ''),
(10544, 'wait', ''),
(10545, 'walk', ''),
(10546, 'wall', ''),
(10547, 'want', ''),
(10548, 'war', ''),
(10549, 'warn', ''),
(10550, 'wash', ''),
(10551, 'watchman', ''),
(10552, 'watchtower', ''),
(10553, 'water', ''),
(10554, 'wave', ''),
(10555, 'way', ''),
(10556, 'we', ''),
(10557, 'weak', ''),
(10558, 'wealth', ''),
(10559, 'wealthy', ''),
(10560, 'weary', ''),
(10561, 'wedding', ''),
(10562, 'week', ''),
(10563, 'weigh', ''),
(10564, 'weight', ''),
(10565, 'well', ''),
(10566, 'west', ''),
(10567, 'wet', ''),
(10568, 'what', ''),
(10569, 'wheat', ''),
(10570, 'when', ''),
(10571, 'where', ''),
(10572, 'whip', ''),
(10573, 'whisper', ''),
(10574, 'white', ''),
(10575, 'who', ''),
(10576, 'whole', ''),
(10577, 'why', ''),
(10578, 'wide', ''),
(10579, 'widow', ''),
(10580, 'wife', ''),
(10581, 'wild', ''),
(10582, 'wilderness', ''),
(10583, 'will', ''),
(10584, 'wind', ''),
(10585, 'window', ''),
(10586, 'wine', ''),
(10587, 'wing', ''),
(10588, 'wings', ''),
(10589, 'winnowing_fork', ''),
(10590, 'winter', ''),
(10591, 'wisdom', ''),
(10592, 'wise', ''),
(10593, 'with', ''),
(10594, 'witness', ''),
(10595, 'woman', ''),
(10596, 'wood', ''),
(10597, 'wool', ''),
(10598, 'word', ''),
(10599, 'Word', ''),
(10600, 'Word_of_God', ''),
(10601, 'work', ''),
(10602, 'world', ''),
(10603, 'worm', ''),
(10604, 'Wormwood', ''),
(10605, 'worry', ''),
(10606, 'worse', ''),
(10607, 'worship', ''),
(10608, 'worth', ''),
(10609, 'worthy', ''),
(10610, 'wrap', ''),
(10611, 'wrath_of_God', ''),
(10612, 'write', ''),
(10613, 'writer', ''),
(10614, 'wrong', ''),
(10615, 'Yahweh', ''),
(10616, 'year', ''),
(10617, 'yellow', ''),
(10618, 'yes', ''),
(10619, 'yoke', ''),
(10620, 'you', ''),
(10621, 'young', ''),
(10622, 'Zacchaeus', ''),
(10623, 'Zadok', ''),
(10624, 'Zarephath', ''),
(10625, 'Zebedee', ''),
(10626, 'Zebulun', ''),
(10627, 'Zechariah', ''),
(10628, 'Zenas', ''),
(10629, 'Zerah', ''),
(10630, 'zero', ''),
(10631, 'Zerubbabel', ''),
(10632, 'Zeus', '');

-- --------------------------------------------------------

--
-- Table structure for table `ot_sources`
--

CREATE TABLE `ot_sources` (
  `srcID` int(10) UNSIGNED NOT NULL,
  `langID` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ot_sources`
--

INSERT INTO `ot_sources` (`srcID`, `langID`, `slug`, `name`) VALUES
(1, 'mzn', 'ulb', 'Unlocked Literal Bible'),
(2, 'hi', 'ulb', 'Unlocked Literal Bible - Hindi'),
(3, 'hi', 'gst', 'Hindi GST - Greek Aligned'),
(4, 'hi', 'tw', 'translationWords'),
(5, 'hi', 'irv', 'Indian Revised Version - Hindi'),
(6, 'hi', 'glt', 'Gateway Literal Text - Hindi'),
(7, 'hi', 'udb', 'Unlocked Dynamic Bible - Hindi'),
(8, 'hi', 'tn', 'translationNotes'),
(9, 'hi', 'tq', 'translationQuestions'),
(10, 'hi', 'iev', 'Hindi IEV'),
(11, 'ur-deva', 'tn', 'translationNotes'),
(12, 'ur-deva', 'ulb', 'Unlocked Literal Bible - Urdu'),
(13, 'ur-deva', 'irv', 'Indian Revised Version (IRV) Urdu'),
(14, 'ur-deva', 'tq', 'translationQuestions'),
(15, 'ur-deva', 'tw', 'translationWords'),
(16, 'sw', 'tq', 'translationQuestions'),
(17, 'sw', 'tn', 'translationNotes'),
(18, 'sw', 'tw', 'translationWords'),
(19, 'sw', 'ulb', 'Swahili Unlocked Literal Bible'),
(20, 'gu', 'tq', 'translationQuestions'),
(21, 'gu', 'irv', 'Indian Revised Version - Gujarati'),
(22, 'gu', 'tn', 'translationNotes'),
(23, 'gu', 'tw', 'translationWords'),
(24, 'gu', 'udb', 'Gujarati Unlocked Dynamic Bible'),
(25, 'gu', 'ulb', 'Gujarati Unlocked Literal Bible'),
(26, 'fr', 'f10', 'French Louis Segond 1910 Bible'),
(27, 'fr', 'tn', 'translationNotes'),
(28, 'fr', 'ulb', 'French ULB'),
(29, 'fr', 'tq', 'translationQuestions'),
(30, 'fr', 'tw', 'translationWords'),
(31, 'th', 'tq', 'translationQuestions'),
(32, 'th', 'tw', 'translationWords'),
(33, 'nag', 'isv', 'Indian Standard Version - Nagamese'),
(34, 'ne', 'tn', 'Translation Notes'),
(35, 'ne', 'ulb', 'Unlocked Literal Bible - Nepali'),
(36, 'ne', 'tq', 'translationQuestions'),
(37, 'ne', 'udb', 'Unlocked Dynamic Bible - Nepali'),
(38, 'ne', 'tw', 'translationWords'),
(39, 'ru', 'tw', 'translationWords'),
(40, 'ru', 'rsb', 'Russian Synodal Bible'),
(41, 'ru', 'ulb', 'Russian Unlocked Literal Bible'),
(42, 'ru', 'rob', 'Russian Open Bible'),
(43, 'ru', 'rlb', 'Russion Literal Bible'),
(44, 'es-419', 'tn', 'translationNotes'),
(45, 'es-419', 'tw', 'translationWords'),
(46, 'es-419', 'ulb', 'Español Latino Americano ULB'),
(47, 'es-419', 'tq', 'translationQuestions'),
(48, 'my', 'ulb', 'Burmese Judson Bible'),
(49, 'tl', 'tw', 'translationWords'),
(50, 'tl', 'ulb', 'Tagalog Unlocked Literal Bible'),
(51, 'tl', 'tn', 'translationNotes'),
(52, 'tl', 'tq', 'translationQuestions'),
(53, 'te', 'irv', 'Indian Revised Version - Telugu'),
(54, 'te', 'ust', 'Indian Easy Version (IEV) Telugu'),
(56, 'te', 'tw', 'translationWords'),
(57, 'te', 'ulb', 'Unlocked Literal Bible - Telugu'),
(58, 'te', 'tn', 'translationNotes'),
(59, 'te', 'tq', 'translationQuestions'),
(60, 'en', 'en_obs-sn', 'unfoldingWord® Open Bible Stories Study Notes'),
(61, 'en', 't4t', 'Translation for Translators'),
(62, 'en', 'ult', 'unfoldingWord® Literal Text'),
(63, 'en', 'ulb', 'Unlocked Literal Bible'),
(64, 'en', 'en_obs-sq', 'unfoldingWord® Open Bible Stories Study Questions'),
(65, 'en', 'tq', 'unfoldingWord® Translation Questions'),
(66, 'en', 'udb', 'Unlocked Dynamic Bible'),
(67, 'en', 'tn', 'unfoldingWord® Translation Notes'),
(68, 'en', 'tw', 'unfoldingWord® Translation Words'),
(69, 'en', 'ust', 'unfoldingWord® Simplified Text'),
(70, 'pt-br', 'tw', 'translationWords'),
(71, 'pt-br', 'blv', 'Portuguese Bíblia Livre BLV'),
(72, 'pt-br', 'ulb', 'Brazilian Portuguese Unlocked Literal Bible'),
(73, 'pt-br', 'tn', 'translationNotes'),
(74, 'pt-br', 'tq', 'translationQuestions'),
(75, 'as', 'tn', 'translationNotes'),
(76, 'as', 'tw', 'translationWords'),
(77, 'as', 'ulb', 'Assamese Unlocked Literal Bible'),
(78, 'as', 'irv', 'Indian Revised Version - Assamese'),
(79, 'as', 'tq', 'translationQuestions'),
(80, 'vi', 'udb', 'Vietnamese Unlocked Dynamic Bible'),
(81, 'vi', 'ulb', 'Vietnamese Unlocked Literal Bible'),
(82, 'vi', 'tw', 'translationWords'),
(83, 'vi', 'tq', 'translationQuestions'),
(84, 'vi', 'tn', 'translationNotes'),
(85, 'ha', 'ulb', 'Hausa Unlocked Literal Bible'),
(86, 'ta', 'ulb', 'Unlocked Literal Bible - Tamil'),
(87, 'ta', 'irv', 'Indian Revised Version - Tamil'),
(88, 'ta', 'tq', 'translationQuestions'),
(89, 'ta', 'tw', 'translationWords'),
(90, 'ta', 'tn', 'translationNotes'),
(91, 'el-x-koine', 'tisch', 'Tischendorf Greek New Testament 8th edition'),
(92, 'el-x-koine', 'ugnt', 'unfoldingWord® Greek New Testament'),
(93, 'el-x-koine', 'maj-rp', 'Greek Majority Text NT'),
(94, 'pa', 'tw', 'translationWords'),
(95, 'pa', 'ulb', 'Punjabi Unlocked Literal Bible'),
(96, 'pa', 'tq', 'translationQuestions'),
(97, 'pa', 'tn', 'translationNotes'),
(98, 'pa', 'irv', 'Indian Revised Version - Punjabi'),
(99, 'kbp', 'ulb', 'Unlocked Literal Bible - Kabiyè'),
(100, 'ee', 'ulb', 'Unlocked Literal Bible - Evegbe'),
(101, 'zh', 'cuv', '新标点和合本'),
(102, 'kn', 'glt', 'Gateway Literal Text - Kannada'),
(103, 'kn', 'iev', 'Indian Easy Version - Kannada'),
(104, 'kn', 'gst', 'Gateway Simplified Text - Kannada'),
(105, 'kn', 'ulb', 'Kannada Unlocked Literal Bible'),
(106, 'kn', 'ust', 'Indian Easy Version - Kannada'),
(107, 'kn', 'irv', 'Indian Revised Version - Kannada'),
(108, 'kn', 'tq', 'translationQuestions'),
(109, 'kn', 'tn', 'translationNotes'),
(110, 'kn', 'tw', 'translationWords'),
(111, 'id', 'tw', 'translationWords'),
(112, 'id', 'ulb', 'Indonesian Unlocked Literal Bible'),
(113, 'id', 'tn', 'translationNotes'),
(114, 'id', 'tq', 'translationQuestions'),
(115, 'id', 'ayt', 'Alkitab Yang Terbuka (The Opened Bible) Old Testament and New Testament'),
(116, 'mr', 'tn', 'translationNotes'),
(117, 'mr', 'tw', 'translationWords'),
(118, 'mr', 'irv', 'Indian Revised Version - Marathi'),
(119, 'mr', 'udb', 'Unlocked Dynamic Bible - Marathi'),
(120, 'mr', 'ulb', 'Unlocked Literal Bible - Marathi'),
(121, 'mr', 'tq', 'translationQuestions'),
(122, 'bn', 'tn', 'translationNotes'),
(123, 'bn', 'irv', 'Indian Revised Version - Bengali'),
(124, 'bn', 'ulb', 'Bengali Unlocked Literal Bible'),
(125, 'bn', 'tq', 'translationQuestions'),
(126, 'bn', 'tw', 'translationWords'),
(127, 'sr-Latn', 'stf', 'Stefanović Novi Zavet'),
(128, 'sr-Latn', 'dkl', 'Danicic Karadzic Latin'),
(129, 'ml', 'tw', 'translationWords'),
(130, 'ml', 'irv', 'Indian Revised Version - Malayalam'),
(131, 'ml', 'tq', 'translationQuestions'),
(132, 'ml', 'tn', 'translationNotes'),
(133, 'ml', 'ulb', 'Unlocked Literal Bible - Malayalam'),
(134, 'lpx', 'ulb', 'Unlocked Literal Bible - Lopit'),
(135, 'ceb', 'udb', 'Unlocked Dynamic Bible - Cebuano'),
(136, 'ceb', 'tw', 'translationWords'),
(137, 'ceb', 'tn', 'translationNotes'),
(138, 'ceb', 'tq', 'translationQuestions'),
(139, 'ceb', 'ulb', 'Cebuano Unlocked Literal Bible'),
(140, 'ilo', 'tw', 'translationWords'),
(141, 'ilo', 'tq', 'translationQuestions'),
(142, 'ilo', 'tn', 'translationNotes'),
(143, 'ilo', 'ulb', 'Unlocked Literal Bible - Ilocano'),
(144, 'las', 'ulb', 'Unlocked Literal Bible - Lama (Togo)'),
(145, 'hna', 'ulb', 'Unlocked Literal Bible - Mina (Cameroon)'),
(146, 'or', 'tn', 'translationNotes'),
(147, 'or', 'tw', 'translationWords'),
(148, 'or', 'ulb', 'Oriya Unlocked Literal Bible'),
(149, 'or', 'udb', 'Oriya Unlocked Dynamic Bible'),
(150, 'or', 'tq', 'translationQuestions'),
(151, 'hr', 'tq', 'translationQuestions'),
(152, 'hr', 'ulb', 'Šarić Hrvatski'),
(153, 'hr', 'tw', 'translationWords'),
(154, 'hr', 'tn', 'translationNotes'),
(155, 'plt', 'tq', 'translationQuestions'),
(156, 'plt', 'ulb', 'Plateau Malagasy Unlocked Literal Bible'),
(157, 'plt', 'tw', 'translationWords'),
(158, 'ar', 'nav', 'New Arabic Version (Ketab El Hayat)'),
(159, 'ar', 'avd', 'ﺎﻠﻜﺗﺎﺑ ﺎﻠﻤﻗﺪﺳ ﺏﺎﻠﻠﻏﺓ ﺎﻠﻋﺮﺒﻳﺓ، ﻑﺎﻧ ﺩﺎﻴﻛ'),
(160, 'fa', 'opv', 'The Old Persian Version'),
(161, 'hu', 'kar', 'Karoli Translation'),
(162, 'hbo', 'uhb', 'unfoldingWord® Hebrew Bible'),
(163, 'kpo', 'ulb', 'Unlocked Literal Bible - Ikposo');

-- --------------------------------------------------------

--
-- Table structure for table `ot_translations`
--

CREATE TABLE `ot_translations` (
  `tID` int(10) UNSIGNED NOT NULL,
  `projectID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `trID` int(10) UNSIGNED NOT NULL,
  `l2chID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `l3chID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `targetLang` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bookProject` enum('ulb','sun','odb') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ulb',
  `abbrID` tinyint(3) NOT NULL DEFAULT '0',
  `bookCode` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `chapter` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `chunk` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `firstvs` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `translatedVerses` mediumtext COLLATE utf8_unicode_ci,
  `translateDone` tinyint(4) NOT NULL DEFAULT '0',
  `dateCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ot_translators`
--

CREATE TABLE `ot_translators` (
  `trID` int(10) UNSIGNED NOT NULL,
  `memberID` int(10) UNSIGNED NOT NULL,
  `eventID` int(10) UNSIGNED NOT NULL,
  `step` enum('none','pray','consume','highlight','verbalize','chunking','read-chunk','blind-draft','multi-draft','rearrange','symbol-draft','self-check','theo-check','peer-review','keyword-check','content-review','final-review','finished') NOT NULL DEFAULT 'pray',
  `currentChapter` int(11) NOT NULL DEFAULT '-1',
  `currentChunk` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `checkerID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checkDone` tinyint(1) NOT NULL DEFAULT '0',
  `hideChkNotif` tinyint(1) NOT NULL DEFAULT '1',
  `translateDone` tinyint(1) NOT NULL DEFAULT '0',
  `verbCheck` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'verbilize checkers (chapter:memberID)',
  `peerCheck` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'peer checkers (chapter:memberID)',
  `kwCheck` text COMMENT 'keyword check checkers (chapter:memberID)',
  `crCheck` text COMMENT 'content review checkers (chapter:memberID)',
  `otherCheck` text COMMENT 'Notes, questions, words check',
  `isChecker` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Is Notes Checker'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `turnusers_lt`
--

CREATE TABLE `turnusers_lt` (
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `name` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `hmackey` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `turn_origin_to_realm`
--

CREATE TABLE `turn_origin_to_realm` (
  `origin` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `turn_realm_option`
--

CREATE TABLE `turn_realm_option` (
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `opt` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `value` char(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `turn_secret`
--

CREATE TABLE `turn_secret` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `realm` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `value` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `expire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ot_abbr`
--
ALTER TABLE `ot_abbr`
  ADD PRIMARY KEY (`abbrID`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `ot_chapters`
--
ALTER TABLE `ot_chapters`
  ADD PRIMARY KEY (`chapterID`),
  ADD UNIQUE KEY `Unique` (`eventID`,`memberID`,`chapter`) USING BTREE,
  ADD KEY `eventID` (`eventID`);

--
-- Indexes for table `ot_checkers_l2`
--
ALTER TABLE `ot_checkers_l2`
  ADD PRIMARY KEY (`l2chID`),
  ADD UNIQUE KEY `memberID` (`memberID`,`eventID`),
  ADD KEY `event` (`eventID`),
  ADD KEY `member` (`memberID`);

--
-- Indexes for table `ot_checkers_l3`
--
ALTER TABLE `ot_checkers_l3`
  ADD PRIMARY KEY (`l3chID`),
  ADD UNIQUE KEY `memberID` (`memberID`,`eventID`),
  ADD KEY `event` (`eventID`),
  ADD KEY `member` (`memberID`);

--
-- Indexes for table `ot_comments`
--
ALTER TABLE `ot_comments`
  ADD PRIMARY KEY (`cID`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `eventID` (`eventID`),
  ADD KEY `chapter` (`chapter`);

--
-- Indexes for table `ot_events`
--
ALTER TABLE `ot_events`
  ADD PRIMARY KEY (`eventID`),
  ADD UNIQUE KEY `pair` (`projectID`,`bookCode`);

--
-- Indexes for table `ot_gateway_projects`
--
ALTER TABLE `ot_gateway_projects`
  ADD PRIMARY KEY (`gwProjectID`);

--
-- Indexes for table `ot_keywords`
--
ALTER TABLE `ot_keywords`
  ADD PRIMARY KEY (`kID`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `eventID` (`eventID`),
  ADD KEY `chapter` (`chapter`);

--
-- Indexes for table `ot_languages`
--
ALTER TABLE `ot_languages`
  ADD PRIMARY KEY (`langID`);

--
-- Indexes for table `ot_members`
--
ALTER TABLE `ot_members`
  ADD PRIMARY KEY (`memberID`);

--
-- Indexes for table `ot_news`
--
ALTER TABLE `ot_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ot_profile`
--
ALTER TABLE `ot_profile`
  ADD PRIMARY KEY (`pID`),
  ADD UNIQUE KEY `pid` (`pID`),
  ADD UNIQUE KEY `mID` (`mID`);

--
-- Indexes for table `ot_projects`
--
ALTER TABLE `ot_projects`
  ADD PRIMARY KEY (`projectID`),
  ADD KEY `gwProjectID` (`gwProjectID`);

--
-- Indexes for table `ot_sail_dict`
--
ALTER TABLE `ot_sail_dict`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ot_sources`
--
ALTER TABLE `ot_sources`
  ADD PRIMARY KEY (`srcID`),
  ADD UNIQUE KEY `langID` (`langID`,`slug`);

--
-- Indexes for table `ot_translations`
--
ALTER TABLE `ot_translations`
  ADD PRIMARY KEY (`tID`),
  ADD UNIQUE KEY `projectID` (`projectID`,`eventID`,`chapter`,`firstvs`),
  ADD KEY `event_cscd` (`eventID`);

--
-- Indexes for table `ot_translators`
--
ALTER TABLE `ot_translators`
  ADD PRIMARY KEY (`trID`),
  ADD UNIQUE KEY `memberID` (`memberID`,`eventID`),
  ADD KEY `event` (`eventID`),
  ADD KEY `member` (`memberID`);

--
-- Indexes for table `turn_secret`
--
ALTER TABLE `turn_secret`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ot_abbr`
--
ALTER TABLE `ot_abbr`
  MODIFY `abbrID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `ot_chapters`
--
ALTER TABLE `ot_chapters`
  MODIFY `chapterID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_checkers_l2`
--
ALTER TABLE `ot_checkers_l2`
  MODIFY `l2chID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_checkers_l3`
--
ALTER TABLE `ot_checkers_l3`
  MODIFY `l3chID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_comments`
--
ALTER TABLE `ot_comments`
  MODIFY `cID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_events`
--
ALTER TABLE `ot_events`
  MODIFY `eventID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_gateway_projects`
--
ALTER TABLE `ot_gateway_projects`
  MODIFY `gwProjectID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_keywords`
--
ALTER TABLE `ot_keywords`
  MODIFY `kID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_members`
--
ALTER TABLE `ot_members`
  MODIFY `memberID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `ot_news`
--
ALTER TABLE `ot_news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_profile`
--
ALTER TABLE `ot_profile`
  MODIFY `pID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT for table `ot_projects`
--
ALTER TABLE `ot_projects`
  MODIFY `projectID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_sail_dict`
--
ALTER TABLE `ot_sail_dict`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10633;

--
-- AUTO_INCREMENT for table `ot_sources`
--
ALTER TABLE `ot_sources`
  MODIFY `srcID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `ot_translations`
--
ALTER TABLE `ot_translations`
  MODIFY `tID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ot_translators`
--
ALTER TABLE `ot_translators`
  MODIFY `trID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `turn_secret`
--
ALTER TABLE `turn_secret`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ot_chapters`
--
ALTER TABLE `ot_chapters`
  ADD CONSTRAINT `event_chapter_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_checkers_l2`
--
ALTER TABLE `ot_checkers_l2`
  ADD CONSTRAINT `event_l2_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_l2_cscd` FOREIGN KEY (`memberID`) REFERENCES `ot_members` (`memberID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_checkers_l3`
--
ALTER TABLE `ot_checkers_l3`
  ADD CONSTRAINT `event_l3_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_l3_cscd` FOREIGN KEY (`memberID`) REFERENCES `ot_members` (`memberID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_comments`
--
ALTER TABLE `ot_comments`
  ADD CONSTRAINT `event_comm_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_events`
--
ALTER TABLE `ot_events`
  ADD CONSTRAINT `prjct_event_cscd` FOREIGN KEY (`projectID`) REFERENCES `ot_projects` (`projectID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_keywords`
--
ALTER TABLE `ot_keywords`
  ADD CONSTRAINT `event_kw_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_profile`
--
ALTER TABLE `ot_profile`
  ADD CONSTRAINT `members_profile_cscd` FOREIGN KEY (`mID`) REFERENCES `ot_members` (`memberID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_projects`
--
ALTER TABLE `ot_projects`
  ADD CONSTRAINT `gwproj_proj_cscd` FOREIGN KEY (`gwProjectID`) REFERENCES `ot_gateway_projects` (`gwProjectID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_translations`
--
ALTER TABLE `ot_translations`
  ADD CONSTRAINT `event_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE;

--
-- Constraints for table `ot_translators`
--
ALTER TABLE `ot_translators`
  ADD CONSTRAINT `event_trans_cscd` FOREIGN KEY (`eventID`) REFERENCES `ot_events` (`eventID`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_trans_cscd` FOREIGN KEY (`memberID`) REFERENCES `ot_members` (`memberID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
